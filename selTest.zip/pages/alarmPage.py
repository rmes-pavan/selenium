from selenium.webdriver.common.by import By
from selTest.locators.locator import locator


class AlarmPage():
    def __init__(self,driver):
        self.driver =driver
        self.alarm_home_page_path = locator.alarm_home_page
        self.alarm_list_view_path = locator.alarm_list_view
        self.alarms_config_path = locator.total_alarms_config
        self.real_time_data_path = locator.real_time_values
        self.alarm_status_path = locator.alarm_status_value
        self.alarm_row_path = locator.alarm_list_row
    def click_alarm_home_page(self):
        self.driver.find_element(By.XPATH,self.alarm_home_page_path).click()
    def click_alarm_list_view(self):
        self.driver.find_element(By.XPATH,self.alarm_list_view_path).click()
    def total_alarm_count(self):
        return self.driver.find_element(By.XPATH, self.alarms_config_path).text
    def real_time_value(self):
        return self.driver.find_element(By.XPATH, self.real_time_data_path).text
    def alarm_status(self):
        return self.driver.find_element(By.XPATH, self.alarm_status_path).text
    def alarm_list_row(self):
        return self.driver.find_element(By.XPATH, self.alarm_row_path).text
