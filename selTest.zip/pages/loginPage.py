from selTest.locators.locator import locator
from selenium.webdriver.common.by import By

class LoginPage():
    def __init__(self,driver):
        self.driver =driver
        self.username_textbox_path = locator.username_textbox_path
        self.password_textbox_path = locator.password_textbox_path
        self.login_btn_path = locator.login_btn_path
    def enter_username(self,username):
        self.driver.find_element(By.XPATH, self.username_textbox_path).clear()
        self.driver.find_element(By.XPATH,self.username_textbox_path).send_keys(username)
    def enter_password(self,password):
        self.driver.find_element(By.XPATH, self.password_textbox_path).clear()
        self.driver.find_element(By.XPATH, self.password_textbox_path).send_keys(password)
    def click_login(self):
        self.driver.find_element(By.XPATH,self.login_btn_path ).click()