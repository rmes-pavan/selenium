from selenium.webdriver.common.by import By
from selTest.locators.locator import locator

class monitorPage():
    def __init__(self,driver):
        self.driver =driver
        self.username_btn_path = locator.username_btn_path
        self.logout_btn_path = locator.logout_btn_path
        self.no_of_assets_path = locator.no_of_assets_home_page

    def no_of_assets(self):
        return self.driver.find_element(By.XPATH,self.no_of_assets_path).text

    def click_username(self):
        self.driver.find_element(By.XPATH,self.username_btn_path).click()

    def clic_logout(self):
        self.driver.find_element(By.XPATH,self.logout_btn_path).click()