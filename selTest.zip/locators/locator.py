rowno =1
class locator():
    #Below all are the xpaths
    username_textbox_path = "/html/body/app-root/div/app-login/div[1]/form/div[1]/input"
    #/html/body/app-root/div/app-login/div[1]/form/div[1]/input

    password_textbox_path = "/html/body/app-root/div/app-login/div[1]/form/div[2]/input"

    login_btn_path = "/html/body/app-root/div/app-login/div[1]/form/div[4]/button"

    username_btn_path = "/html/body/app-root/div/app-admin-layout/app-header-nav/header/div[3]/div[3]/button"
    #/html/body/app-root/div/app-admin-layout/app-header-nav/header/div[2]/div[2]/button

    logout_btn_path = "/html/body/app-root/div/app-admin-layout/app-header-nav/header/div[3]/div[3]/div/div/button[2]"

    no_of_assets_home_page = "/html/body/app-root/div/div/section/app-monitor/div/app-asset-summary/div/mat-card/mat-card-content/div/table/tbody/tr/td[2]"

    alarm_home_page= "/html/body/app-root/div/div/app-common-nav/aside/div/cdk-accordion/cdk-accordion-item[3]/div[1]"

    alarm_list_view = "/html/body/app-root/div/div/app-common-nav/aside/div/cdk-accordion/cdk-accordion-item[3]/div[2]/ul/li[2]"

    total_alarms_config = "/html/body/app-root/div/div/section/app-alarm-list/div[1]/div[2]/div/mat-paginator/div/div/div[2]/div"

    alarm_list_row = f"/html/body/app-root/div/div/section/app-alarm-list/div[1]/div[2]/div/div/table/tbody/tr[{rowno}]"

    real_time_values = f"/html/body/app-root/div/div/section/app-alarm-list/div[1]/div[2]/div/div/table/tbody/tr[{rowno}]/td[6]"

    alarm_status_value = f"/html/body/app-root/div/div/section/app-alarm-list/div[1]/div[2]/div/div/table/tbody/tr[{rowno}]/td[6]"

    #Browser loading ,Collecting one-two elements from ech and every page

    home_assets = "/html/body/app-root/div/div/app-common-nav/aside/div/cdk-accordion/cdk-accordion-item[2]/div[1]/div"

    assets_count_in_assets_page = "/html/body/app-root/div/div/section/app-assets/app-asset-dashboard/div/div[1]/h2"

    assets_heading = "/html/body/app-root/div/div/section/app-assets/app-asset-dashboard/div/div[2]/div/div[1]/table/thead/tr/th[2]/div/div[1]"

    one_of_the_asset = "/html/body/app-root/div/div/section/app-assets/app-asset-dashboard/div/div[2]/div/div[1]/table/tbody/tr[1]/td[2]"

    value_of_one_of_asset = "/html/body/app-root/div/div/section/app-resource/div/app-asset-summary/div/div/div[2]/div/div[1]/div[2]/app-asset-summary-child[1]/app-gauge/div[2]/span[1]"

    alarms_page_of_asset = "/html/body/app-root/div/div/app-common-nav/aside/div/cdk-accordion/cdk-accordion-item[2]/div[2]/ul/li[1]"

    maintank_page_of_asset = "/html/body/app-root/div/div/app-common-nav/aside/div/cdk-accordion/cdk-accordion-item[3]/div[1]"

    one_of_the_vital = "/html/body/app-root/div/div/section/app-vital/app-commonvital/div[1]/div[2]/div/div/table/tbody/tr[1]/td[2]"







