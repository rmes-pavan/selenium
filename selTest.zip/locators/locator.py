class locator():
    username_textbox_path = "/html/body/app-root/div/app-login/div[1]/form/div[1]/input"
    password_textbox_path = "/html/body/app-root/div/app-login/div[1]/form/div[2]/input"
    login_btn_path = "/html/body/app-root/div/app-login/div[1]/form/div[4]/button"
    username_btn_path = "/html/body/app-root/div/app-admin-layout/app-header-nav/header/div[2]/div[2]/button"
    logout_btn_path = "/html/body/app-root/div/app-admin-layout/app-header-nav/header/div[2]/div[2]/div/div/button[2]"
