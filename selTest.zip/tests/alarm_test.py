from selenium import webdriver
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), "..",".."))
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
import unittest
from selTest.pages.loginPage import LoginPage
from selTest.pages.configPage import ConfigPage
from selTest.pages.alarmPage import AlarmPage
from selTest.pages.monitoringPage import monitorPage
import time
import HtmlTestRunner


class Alarm_list(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        chrome_options = Options()
        chrome_options.add_argument("--headless")
        cls.driver = webdriver.Chrome(options=chrome_options)
        # cls.driver = webdriver.Chrome(executable_path='/usr/bin/chromedriver')
        # cls.driver = webdriver.Chrome("C:\Program Files (x86)\chromedriver.exe")
        # cls.driver.implicitly_wait(5)
        # cls.driver.maximize_window()

    def test_count_alarms_config_1(self):
        driver = self.driver
        driver.implicitly_wait(5)
        driver.get(f'http://192.168.60.79/monitor/home')
        login = LoginPage(driver)
        login.enter_username("demo@rmes.com")
        login.enter_password("test")
        login.click_login()
        alarm_page = AlarmPage(driver)
        alarm_page.click_alarm_home_page()
        alarm_page.click_alarm_list_view()
        total_no_alarm = alarm_page.total_alarm_count()
        total_no_alarm = total_no_alarm.split("of")
        total_no_alarm = int(total_no_alarm[1].strip())
        if total_no_alarm != 1:
            raise Exception("The total alarm count should be one")
        else:
            print("Test1 Completed")

    def test_realtime_value_2(self):
        driver = self.driver
        driver.implicitly_wait(5)
        alarm_page = AlarmPage(driver)
        time.sleep(1)
        realtime_value = alarm_page.real_time_value()
        if realtime_value == "":
            raise Exception("Real time value is not comming")
        else:
            print("Test2 completed")

        alarm_row_value = AlarmPage(driver)
        print(alarm_row_value.alarm_list_row())

    def test_sate_of_alarm_3(self):
        driver = self.driver
        driver.implicitly_wait(5)
        alarm_page = AlarmPage(driver)
        realtime_value = alarm_page.real_time_value()
        if realtime_value == "":
            raise Exception("Real time value is not comming")
        else:
            count = 1
            while True:
                alarm_page = AlarmPage(driver)
                realtime_value = alarm_page.real_time_value()
                if count ==60:
                    break;
                elif float(realtime_value) >50:
                    count = 60
                    time.sleep(1)
                    alarm_state = AlarmPage(driver)
                    #No alarm even after threshold case
                    if alarm_state.alarm_status() == "":
                        raise Exception("Couldn't get an alarm even after crossing threshold")
                        break;
                    #Alarm is working
                    elif alarm_state.alarm_status() == "ON":
                        print("Test 3 Completed")
                        break;
                else:
                    count+=1
                    time.sleep(1)
                    if count == 60:
                        raise Exception("Couldn't get an alarm even after waiting for 60 sec")

    @classmethod
    def tearDownClass(cls):
        cls.driver.close()
        cls.driver.quit()

class First_Login(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        chrome_options = Options()
        chrome_options.add_argument("--headless")
        cls.driver = webdriver.Chrome(options=chrome_options)
        # cls.driver = webdriver.Chrome(executable_path='/usr/bin/chromedriver')
        # cls.driver = webdriver.Chrome("C:\Program Files (x86)\chromedriver.exe")
        cls.driver.implicitly_wait(5)
        # cls.driver.maximize_window()

    def test_login_test_2(self):
        driver = self.driver
        driver.get(f'http://192.168.60.79/monitor/home')
        login = LoginPage(driver)
        login.enter_username("demo@rmes.com")
        login.enter_password("test")
        login.click_login()
        monitor = monitorPage(driver)
        time.sleep(1)
        if monitor.no_of_assets() == "":
            raise Exception("browser loading issue even after 1sec")
        monitor.click_username()
        monitor.clic_logout()

    def test_login_test_1(self):
        driver = self.driver
        driver.get(f'http://192.168.60.79/monitor/home')
        login = LoginPage(driver)
        login.enter_username("demo@rmes.com")
        login.enter_password("test")
        login.click_login()
        monitor = monitorPage(driver)
        time.sleep(1)
        if monitor.no_of_assets() == "":
            raise Exception("browser loading issue even after 1sec")
        print(monitor.no_of_assets())
        monitor.click_username()
        monitor.clic_logout()

        # self.driver.find_element(By.XPATH,"/html/body/app-root/div/app-login/div[1]/form/div[1]/input").send_keys("demo@rmes.com")
        # self.driver.find_element(By.XPATH,"/html/body/app-root/div/app-login/div[1]/form/div[2]/input").send_keys("test")
        # self.driver.find_element(By.XPATH,"/html/body/app-root/div/app-login/div[1]/form/div[4]/button").click()
        # self.driver.find_element(By.XPATH, "/html/body/app-root/div/app-admin-layout/app-header-nav/header/div[2]/div[2]/button").click()
        # self.driver.find_element(By.XPATH, "/html/body/app-root/div/app-admin-layout/app-header-nav/header/div[2]/div[2]/div/div/button[2]").click()
    @classmethod
    def tearDownClass(cls):
        cls.driver.close()
        cls.driver.quit()
        print("Test completed")
def suite():
    suite = unittest.TestSuite()
    # TestDemo
    suite.addTest(Alarm_list('test_count_alarms_config_1'))
    suite.addTest(Alarm_list('test_realtime_value_2'))
    suite.addTest(Alarm_list("test_sate_of_alarm_3"))
    suite.addTest(First_Login("test_login_test_1"))
    suite.addTest(First_Login("test_login_test_2"))
    return suite

suite = suite()
unittest.TextTestRunner(verbosity=2)
# output = open(r"C:\Users\chemeli\Documents\RMES\python\Caputre_data\selTest\reports\index.html", 'w')
runner = HtmlTestRunner.HTMLTestRunner(output=r"../reports",report_name="Alarm_test", report_title='Alarm Test Report', descriptions='This is a test',combine_reports=True)
runner.run(suite)


# output =  open(r"C:/Users/chemeli/Documents/RMES/python/Caputre_data/selTest/reports/test1.html",'w', encoding='utf-8')
# if __name__ == "__main__":
    # unittest.main(testRunner = HtmlTestRunner.HTMLTestRunner(output=r"C:\Users\chemeli\Documen    ts\RMES\python\Caputre_data\selTest\reports",report_title="index"))