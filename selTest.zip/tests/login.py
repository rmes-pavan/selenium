from selenium import webdriver
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), "..",".."))
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
import unittest
from selTest.pages.loginPage import LoginPage
from selTest.pages.monitoringPage import monitorPage
import time
import HtmlTestRunner



class First_Login(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        # chrome_options = Options()
        # chrome_options.add_argument("--headless")
        # cls.driver = webdriver.Chrome(options=chrome_options)
        # cls.driver = webdriver.Chrome(executable_path='/usr/bin/chromedriver')
        cls.driver = webdriver.Chrome("C:\Program Files (x86)\chromedriver.exe")
        cls.driver.implicitly_wait(5)
        cls.driver.maximize_window()

    def test_login_test_2(self):
        driver = self.driver
        driver.get(f'http://192.168.60.79/monitor/home')
        login = LoginPage(driver)
        login.enter_username("demo@rmes.com")
        login.enter_password("test")
        login.click_login()
        monitor = monitorPage(driver)
        time.sleep(1)
        if monitor.no_of_assets() == "":
            raise Exception("browser loading issue even after 1sec")
        monitor.click_username()
        monitor.clic_logout()

    def test_login_test_1(self):
        driver = self.driver
        driver.get(f'http://192.168.60.79/monitor/home')
        login = LoginPage(driver)
        login.enter_username("demo@rmes.com")
        login.enter_password("test")
        login.click_login()
        monitor = monitorPage(driver)
        time.sleep(1)
        if monitor.no_of_assets() == "":
            raise Exception("browser loading issue even after 1sec")
        print(monitor.no_of_assets())
        monitor.click_username()
        monitor.clic_logout()

        # self.driver.find_element(By.XPATH,"/html/body/app-root/div/app-login/div[1]/form/div[1]/input").send_keys("demo@rmes.com")
        # self.driver.find_element(By.XPATH,"/html/body/app-root/div/app-login/div[1]/form/div[2]/input").send_keys("test")
        # self.driver.find_element(By.XPATH,"/html/body/app-root/div/app-login/div[1]/form/div[4]/button").click()
        # self.driver.find_element(By.XPATH, "/html/body/app-root/div/app-admin-layout/app-header-nav/header/div[2]/div[2]/button").click()
        # self.driver.find_element(By.XPATH, "/html/body/app-root/div/app-admin-layout/app-header-nav/header/div[2]/div[2]/div/div/button[2]").click()
    @classmethod
    def tearDownClass(cls):
        cls.driver.close()
        cls.driver.quit()
        print("Test completed")

class Second_Login(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        # chrome_options = Options()
        # chrome_options.add_argument("--headless")
        # cls.driver = webdriver.Chrome(options=chrome_options)
        # cls.driver = webdriver.Chrome(executable_path='/usr/bin/chromedriver')
        cls.driver = webdriver.Chrome("C:\Program Files (x86)\chromedriver.exe")
        cls.driver.implicitly_wait(5)
        cls.driver.maximize_window()

    def test_login_test_3(self):
        driver = self.driver
        driver.get(f'http://192.168.60.79/monitor/home')
        login = LoginPage(driver)
        login.enter_username("demo@rmes.com")
        login.enter_password("test")
        login.click_login()
        monitor = monitorPage(driver)
        time.sleep(1)
        if monitor.no_of_assets() == "":
            raise Exception("browser loading issue even after 1sec")
        monitor.click_username()
        monitor.clic_logout()

    def test_login_test_4(self):
        driver = self.driver
        driver.get(f'http://192.168.60.79/monitor/home')
        login = LoginPage(driver)
        login.enter_username("demo@rmes.com")
        login.enter_password("test")
        login.click_login()
        monitor = monitorPage(driver)
        time.sleep(1)
        if monitor.no_of_assets() == "":
            raise Exception("browser loading issue even after 1sec")
        print(monitor.no_of_assets())
        monitor.click_username()
        monitor.clic_logout()

        # self.driver.find_element(By.XPATH,"/html/body/app-root/div/app-login/div[1]/form/div[1]/input").send_keys("demo@rmes.com")
        # self.driver.find_element(By.XPATH,"/html/body/app-root/div/app-login/div[1]/form/div[2]/input").send_keys("test")
        # self.driver.find_element(By.XPATH,"/html/body/app-root/div/app-login/div[1]/form/div[4]/button").click()
        # self.driver.find_element(By.XPATH, "/html/body/app-root/div/app-admin-layout/app-header-nav/header/div[2]/div[2]/button").click()
        # self.driver.find_element(By.XPATH, "/html/body/app-root/div/app-admin-layout/app-header-nav/header/div[2]/div[2]/div/div/button[2]").click()
    @classmethod
    def tearDownClass(cls):
        cls.driver.close()
        cls.driver.quit()
        print("Test completed")

def suite():
    suite = unittest.TestSuite()
    # TestDemo
    suite.addTest(First_Login('test_login_test_1'))
    suite.addTest(First_Login('test_login_test_2'))
    suite.addTest(Second_Login("test_login_test_3"))
    suite.addTest(Second_Login("test_login_test_4"))
    return suite

suite = suite()
unittest.TextTestRunner(verbosity=2)
# output = open(r"C:\Users\chemeli\Documents\RMES\python\Caputre_data\selTest\reports\index.html", 'w')
runner = HtmlTestRunner.HTMLTestRunner(output=r"C:\Users\chemeli\Documents\RMES\python\selenium\selTest\reports",report_name="Login_test", report_title='Login Test Report', descriptions='This is a test',combine_reports=True)
runner.run(suite)
# if __name__ == "__main__":






# if __name__ == "__main__":
#     loader = unittest.TestLoader()
#     suit = unittest.TestSuite((
#         loader.loadTestsFromTestCase(First_Login),
#         loader.loadTestsFromTestCase(Second_Login)
#     ))
#     outputfile = open(r"C:\Users\chemeli\Documents\RMES\python\Caputre_data\selTest\reports\index.html","w")
#     testRunner = HtmlTestRunner.HTMLTestRunner(output=outputfile, report_title="This is login test")
#     testRunner.run(suit)



# login = LoginTest()
# login.setUpClass()
# login.login_test()
# login.tearDownClass()


# try:
#     tag20 = WebDriverWait(driver, 5).until(
#         EC.presence_of_element_located((By.CLASS_NAME,'user-icon')))
# except:
#     pass
# driver.find_elements_by_class_name('user-icon')[0].click()
# driver.find_elements_by_class_name('signOutBtn')[0].click()
# try:
#     tag20 = WebDriverWait(driver, 5).until(
#         EC.presence_of_element_located((By.XPATH,'/html/body/div[2]/div/div/snack-bar-container/div/div/simple-snack-bar/span')))
# except:
#     pass




# asset_id =[]
# count = 0
# for row in result:
#     count+=1
#     asset_id.append(row[0])
#     driver.execute_script(f"window.open('about:blank','{row[0]}');")
#     driver.switch_to.window(f"{row[0]}")
#     driver.get(f'http://192.168.60.200/resource/transformer/{row[0]}/summary')
#     username = driver.find_element_by_xpath("/html/body/app-root/div/app-login/div[1]/form/div[1]/input")
#     username.send_keys("pguntupalli@ruggedmonitoring.com")
#     password = driver.find_element_by_xpath("/html/body/app-root/div/app-login/div[1]/form/div[2]/input")
#     password.send_keys("test")
#     username.send_keys(Keys.RETURN)
#     if count == 10:
#         break



